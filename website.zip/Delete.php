<?php
    require_once("product.php");
    
    if (products::deleteData()){
        header("Location:https://elemental-apparatus.000webhostapp.com/");    
    }else {
        header("Location:https://elemental-apparatus.000webhostapp.com/add.php");
    }
    
    

?>