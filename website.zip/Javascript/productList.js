switcher()
function switcher(){
    const vals = document.getElementById("productType").options
    val = document.getElementById("productType").value
    if (vals[0].value == val) {
        dvd = document.getElementById("dvd")
        dvd.style.display = "block"
        book = document.getElementById("book")
        book.style.display = "none"
        furniture = document.getElementById("furniture")
        furniture.style.display = "none"
    }else if (vals[1].value == val){
        book = document.getElementById("book")
        book.style.display = "block"
        dvd = document.getElementById("dvd")
        dvd.style.display = "none"
        furniture = document.getElementById("furniture")
        furniture.style.display = "none"
    }else {
        furniture = document.getElementById("furniture")
        furniture.style.display = "block"
        dvd = document.getElementById("dvd")
        dvd.style.display = "none"
        book = document.getElementById("book")
        book.style.display = "none"
    }
    // for (var i = 0; i<=vals.length;i++){
    //   if (val == v){
    //     dvd = document.getElementById("dvd")
    //     dvd.style.display = "block"
    //     book = document.getElementById("book")
    //     book.style.display = "none"
    //     furniture = document.getElementById("furniture")
    //     furniture.style.display = "none"
    //     // dvdButton = document.getElementById('dvd-but')
    //     // dvdButton.style.display = 'inline'
    //     // bookButton = document.getElementById('book-but')
    //     // bookButton.style.display = 'none'
    //     // furnitureButton = document.getElementById('furniture-but')
    //     // furnitureButton.style.display = 'none'
        
    //     // saveButton.value
    //     }   
    //     else if (val === "book"){
    //     book = document.getElementById("book")
    //     book.style.display = "block"
    //     dvd = document.getElementById("dvd")
    //     dvd.style.display = "none"
    //     furniture = document.getElementById("furniture")
    //     furniture.style.display = "none"
    //     // dvdButton = document.getElementById('dvd-but')
    //     // dvdButton.style.display = 'none'
    //     // bookButton = document.getElementById('book-but')
    //     // bookButton.style.display = 'inline'
    //     // furnitureButton = document.getElementById('furniture-but')
    //     // furnitureButton.style.display = 'none'
    //     }
    //     else {
    //     furniture = document.getElementById("furniture")
    //     furniture.style.display = "block"
    //     dvd = document.getElementById("dvd")
    //     dvd.style.display = "none"
    //     book = document.getElementById("book")
    //     book.style.display = "none"
    //     // dvdButton = document.getElementById('dvd-but')
    //     // dvdButton.style.display = 'none'
    //     // bookButton = document.getElementById('book-but')
    //     // bookButton.style.display = 'none'
    //     // furnitureButton = document.getElementById('furniture-but')
    //     // furnitureButton.style.display = 'inline'
    //     } 
    // }
    
    // return val;
}   

// FORM validation

function validationForm (form){

    var SKU    =    document.forms["product_FORM"]["sku"].value
    var name   =    document.forms["product_FORM"]["name"].value
    var price  =    document.forms["product_FORM"]["price"].value
    var size   =    document.forms["product_FORM"]["size"].value
    var weight =    document.forms["product_FORM"]["weight"].value
    var width  =    document.forms["product_FORM"]["w"].value
    var length =    document.forms["product_FORM"]["l"].value
    var height =    document.forms["product_FORM"]["h"].value
    var prodType =  document.getElementById("productType").value;
    // var SKU    =    document.querySelector("#sku")
    // var name   =    document.querySelector("#name")
    // var price  =    document.querySelector("#price")
    // var size   =    document.querySelector("#size")
    // var weight =    document.querySelector("#weight")
    // var width  =    document.querySelector("#w")
    // var length =    document.querySelector("#l")
    // var height =    document.querySelector("#h")

    var success = true 
    
    var errors = ""
    var errorArray = []

    if (SKU == "" || SKU == null){
        // document.getElementById("sku").style.borderColor = "red"
        errorArray.push("SKU is empty")
        // document.getElementById("sku").style.border = "solid 1px red"
        success = false
    }
    if (name == "" || name == null){
        // document.getElementById("sku").style.borderColor = "red"
        errorArray.push("Name is empty")
        // document.getElementById("name").style.border = "solid 1px red"
        success = false
    }
    if (price == "" || price == null){
        // document.getElementById("sku").style.borderColor = "red"
        errorArray.push("price is empty")
        // document.getElementById("price").style.border = "solid 1px red"
        success = false
    }
    if (prodType === "dvd"){
        if (size == "" || size == null){
            errorArray.push("size is empty")
            // document.getElementById("dvd").style.border = "solid 1px red"
            success = false;
        }

    }else if (prodType === "book"){
        if (weight == "" || weight == null){
            errorArray.push("weight is empty")
            // document.getElementById("book").style.border = "solid 1px red"
            success = false;
        }
    }
    else {
        if ((width == "" || length == "" || height == "")){
            errorArray.push("some dimensions are empty")
            success = false
        }
    }

    // if (size == "" || SKU == null){
    //     // document.getElementById("sku").style.borderColor = "red"
    //     errorArray.push("Name is empty")
    //     success = false
    // }
    var count = 0
    if (errorArray.length > 0){
        // alert("ok")
        errorArray.forEach(function (error){
            // if (count == 0){
                errors += error+"<br>"
                
            // }
            
        })
    }

    document.getElementById("error").innerHTML = errors
    document.getElementById("error").style.display = "block"

    // function add_errors(error){
    //     errors += error
    // }

    return success

}

function turnRed(event){
    if (event.value == "") {
        event.style.border = "solid 1px red"
        return
    }
    event.style.border = "solid 1px grey"

    // if (event.value == ""){
    //     event.style.border = "solid 1px red"
    // }
    
}

function CheckValid(){
    if (validationForm()){
        document.getElementById("form_submitted").value = "0"
        // alert(document.getElementById("form_submitted").value)
    }
}


