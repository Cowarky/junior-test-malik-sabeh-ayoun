<?php 
    require_once "Server.php";
    require_once "product.php";
    
?>



<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="styles/stylesheet.css">
    <title>Product Add</title>
    <?php
        // function set_url( $url )
        // {
        //     echo "<script>history.replaceState({},'','$url');</script>";
        // }
        // set_url("https://elemental-apparatus.000webhostapp.com/addproduct");
    ?>
</head>
<body>
    <div class="photo-container">

    </div>
    <form  id="product_form" name = "product_FORM" method="POST" onsubmit="return validationForm(this)">
    <span class="header-1">
        <div class="head-1">
            <h1>
                Product Add
            </h1>   
            <!-- <button>
                save
            </button> -->
            <input type="submit" value="save" name="submit" style="width: 50px" onclick="CheckValid()">
            <input type="hidden" id="form_submitted" name="form-sub"value="1"/>
           
            </button> -->
            <input type="reset" value="cancel">
            <hr>
        </div>
        
    </span>
    <div class="wrapper-1">
       <div>
            
            <label>
                SKU
            </label>
            <input type="text" id = "sku" name="sku" onfocus="turnRed(this)" onkeypress="turnRed(this)" onclick="turnRed(this)" onfocusout="turnRed(this)">
            <p>

            </p>

            <label>
                Name
            </label>
            <input type="text" id = "name" name="name" onfocus="turnRed(this)" onkeypress="turnRed(this)" onclick="turnRed(this)" onfocusout="turnRed(this)">
            <p>

            </p>

            <label>
                price ($)
            </label>
            <input type="text" id = "price" name = "price" onfocus="turnRed(this)" onkeypress="turnRed(this)" onclick="turnRed(this)" onfocusout="turnRed(this)">
            <p>

            </p>

            <label>
                Type switcher
            </label>
            
            <select name="product" id="productType" onclick="switcher()" > 
                <option value="dvd">
                    DVD
                </option>
                
                <option value="book">
                    Book
                </option>
                <option value="furniture">
                    Furniture
                </option>
            </select>
            <hr>
            <div id="dvd">
               <label>
                   Size: 
               </label>
               <input type="text" id = "size" name = "size" onfocus="turnRed(this)" onkeypress="turnRed(this)" onclick="turnRed(this)" onfocusout="turnRed(this)">
               <p>

               </p>
            </div>

            <div id="book">
               <label>
                   weight: 
               </label>
               <input type="text" id = "weight" name="weight" onfocus="turnRed(this)" onkeypress="turnRed(this)" onclick="turnRed(this)" onfocusout="turnRed(this)">
               <p>

               </p>
            </div>
            <div id="furniture">
                <label>
                    Height (CM): 
                </label>
                <input type="text" name = "h" id = "h" onfocus="turnRed(this)" onkeypress="turnRed(this)" onclick="turnRed(this)" onfocusout="turnRed(this)">
                <p>

                </p>
                <label>
                    Width (CM): 
                </label>
                <input type="text" name = "w" id = "w" onfocus="turnRed(this)" onkeypress="turnRed(this)" onclick="turnRed(this)" onfocusout="turnRed(this)">
                <p>

                </p>
                <label>
                    Length (CM): 
                </label>
                <input type="text" name = "l" id = "l" onfocus="turnRed(this)" onkeypress="turnRed(this)" onclick="turnRed(this)" onfocusout="turnRed(this)">
                <p>

                </p>
            </div>
            <div id="error">
                
            </div>
            
            
       </div>
    </div>
    </form>
    
   <script src="Javascript/productList.js">
       

       
   </script>

   <?php

    
    if ($_POST["form-sub"] == "0"){
        // echo "<script>alert('ok');</script>";
        // set_url("https://elemental-apparatus.000webhostapp.com/");
        $d = new dvd();
        $b = new book();
        $f = new furniture();
        if ($d->InsertItems() == true){
            header("Location:https://elemental-apparatus.000webhostapp.com/");
            exit();
        }
        
        else if ($b->InsertItems() == true){
            header("Location:https://elemental-apparatus.000webhostapp.com/");
        }
        
        else if ($f->InsertItems() == true){
            header("Location:https://elemental-apparatus.000webhostapp.com/");
        }
    }
    
   
    // echo 
   ?>

    
</body>
</html>