<?php

class Database {
    private $host = 'localhost';
    private $username = 'id18124192_product';
    private $password = '#SJ9-Au(^(7G7(V-';
    private $conn;
    private $name;

    function __construct($name)
    {   
        $this->name = $name;
    }

    public function db_connect(){
        $this->conn = new mysqli($this->host,$this->username,$this->password,$this->name);

        if ($this->conn->connect_errno){
            // echo "error";
            return false;
        }
        // echo "connected";
        return true;
    }

    public function query($query) {
        return $this->conn->query($query);
    }


}

?>