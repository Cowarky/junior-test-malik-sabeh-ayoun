<?php
    require_once("Server.php");
    // require_once("index.php");

    abstract class products{
        private static $SKU;
        private static $name;
        private static $price;

        abstract public function GetData(): string;

        abstract public function InsertItems(): bool;

        public static function deleteData(){
            $db = new Database("id18124192_productlist");
            $connected = $db->db_connect();
            if (!$connected){
                return false;
            }

            $check = $_POST['checkbox'];
            // print_r ($_POST['checkbox']);
            foreach($check as $box){
                // echo $box;
                $db->query("delete from dvd where SKU = " . $box . "; ");
                $db->query("delete from book where SKU = " . $box . "; ");
                $db->query("delete from furniture where SKU = " . $box . "; ");

            }
            return true;
        }

        public static function Get_name(){
            return self::$name;
        }
        public static function Get_SKU(){
            return self::$SKU;
        }
        public static function Get_price(){
            return self::$price;
        }

        public static function Set_SKU($SKU){
            self::$SKU = $SKU;
        }

        public static function Set_Name($name){
            self::$name = $name;
        }
        
        public static function Set_price($price){
            self::$price = $price;
        }
        
    }

    class dvd extends products{
        private $size;

        function __construct(){
            
        }

        public function GetData(): string{
            $str = "";
            $db = new Database("id18124192_productlist");
            $db->db_connect();
            $sql = "select * from dvd";
            $result = $db->query($sql);
            // print_r($result);
            if ($result->num_rows > 0){
                while ($row = $result->fetch_assoc()){
                    // print_r($row);
                    $str .= " <input type='checkbox' class='delete-checkbox' name='checkbox[]' value='" . $row['SKU'] . "'> <div class='product'>
                    <div class = 'product-text'>" 
                    . $row["name"] . "<br> " 
                    . $row["price"] . "<br> " 
                    . $row["size"] .
                    " </div> 
                    </div>";
                }
            }
            return $str;
            
        }

        public function InsertItems(): bool{
            $flag = false;
            $db = new Database('id18124192_productlist');
            $db->db_connect();
            if ($_POST['size'] == ""){
                return $flag;
            }
            products::Set_SKU($_POST['sku']);
            products::Set_Name($_POST['name']);
            products::Set_price($_POST['price']);
            
            $this->Set_size($_POST['size']);

            $query = "insert into dvd (SKU, name, price, size) VALUES ('".products::Get_SKU()."', '".products::Get_Name()."', '".products::Get_price()."', '".$this->Get_size()."')";
            
            if ($db->query($query)){
                $flag = true;
            }
            // header("Location:/productlist-4");
            return $flag;
        }


        // public function InsertItem($conn): bool{
        //     // echo products::Get_SKU();
        //     $sql = "INSERT into dvd (SKU, name, price, size) VALUES ('". products::Get_SKU() ."','". products::Get_name() ."','". products::Get_price() . "','". $this->Get_size() ."')";
        //     if ($conn->connect_errno){
        //         return false;
        //     }
        //     $result = $conn->query($sql);
        //     echo ($result);
        //     if ($result){
        //         echo "<script> alert('inserted') </script>";
        //         return true;
        //     }
        //     echo "<script> alert('not inserted') </script>";
        //     return false;
        // }

        // public function DeleteItems($conn, $array){
        //     $id = implode(',',$array);
        //     echo $id;

        //     function CheckSKU($conn, $id){
        //         $sql = "SELECT SKU from dvd SKU = ".$id;
        //         $_SKU = array();

        //         $result = $conn->query($sql);
        //         if ($result->num_rows > 0){
                    
        //             while ($row = $result->fetch_assoc()){
        //                 // print_r($row);
        //                 // echo $row;
        //                 array_push($_SKU, $row);
        //             }
        //         }   
        //         // echo "<script> alert('ok') </script>";
        //         return $_SKU;
        //     }
        //     echo CheckSKU($conn, $id);
        //     // $sql = "delete from dvd where SKU = ". $id;

        //     // if ($conn->connect_errno){
        //     //     return false;
        //     // }
        //     // $result = $conn->query($sql);
        //     // echo ($result);
        //     // if ($result){
        //     //     echo "<script> alert('deleted') </script>";
        //     //     return true;
        //     // }
        //     // echo "<script> alert('deleted') </script>";
        //     return false;
        // }

        public function __toString(){
            return "ID: " . $this->Get_SKU() 
            . "<br> Name: " . $this->Get_name() 
            . "<br> price: " . $this->Get_price() 
            ."<br> size: " . $this->Get_size() 
            . "<br>";
        }

        // public function Set_SKU($SKU){
        //     $this->SKU = $SKU;
        // }

        // public function Set_Name($name){
        //     $this->name = $name;
        // }
        
        // public function Set_price($price){
        //     $this->price = $price;
        // }

        public function Set_size($size){
            $this->size = $size;
        }

        public function Get_size(){
            return $this->size;
        }
    }

    class book extends products{
        private $weight;

        function __construct(){
            
        }

        public function GetData(): string{
            $str = "";
            $db = new Database("id18124192_productlist");
            $connected = $db->db_connect();

            if (!$connected){ return "not connected"; }

            $sql = "select * from book";
            $result = $db->query($sql);
            // print_r($result);
            if ($result->num_rows > 0){
                while ($row = $result->fetch_assoc()){
                    // print_r($row);
                    $str .=  "<input type='checkbox' class='delete-checkbox'name='checkbox[]' value='" . $row['SKU'] . "'><div class='product'>
                    " 
                    . $row["name"] . "<br> " 
                    . $row["price"] . "<br> " 
                    . $row["weight"] .
                    "</div>";
                }
            }
            return $str;
        }

        public function InsertItems(): bool{
            $flag = false;
            $db = new Database('id18124192_productlist');
            $db->db_connect();
            if ($_POST['weight'] == ""){
                return $flag;
            }
            products::Set_SKU($_POST['sku']);
            products::Set_Name($_POST['name']);
            products::Set_price($_POST['price']);
            
            $this->Set_weight($_POST['weight']);

            $query = "insert into book (SKU, name, price, weight) VALUES ('".products::Get_SKU()."', '".products::Get_Name()."', '".products::Get_price()."', '".$this->Get_weight()."')";
            
            if ($db->query($query)){
                $flag = true;
            }
            return $flag;
        }

        public function __toString(){
            return "ID: " . $this->Get_SKU() 
            . "<br> Name: " . $this->Get_name() 
            . "<br> price: " . $this->Get_price() 
            . "<br> size: " . $this->Get_weight() 
            . "<br>";
        }

        // public function Set_SKU($SKU){
        //     $this->SKU = $SKU;
        // }

        // public function Set_Name($name){
        //     $this->name = $name;
        // }
        
        // public function Set_price($price){
        //     $this->price = $price;
        // }

        public function Set_weight($weight){
            $this->weight = $weight;
        }

        public function Get_weight(){
            return $this->weight;
        }

    }

    class furniture extends products{
        private $w;
        private $l;
        private $h;

        // function __construct($id, $name, $price, $w, $h, $l){
        //     parent::__construct($id,$name,$price);
        //     $this->w = $w;
        //     $this->l = $l;
        //     $this->h = $h;
        // }
        public function __construct(){
            // parent::__construct();
        }

        public function GetData(): string{
            $str = "";
            $db = new Database("id18124192_productlist");
            $connected = $db->db_connect();

            if (!$connected){ return "not connected"; }

            $sql = "select * from furniture";
            $result = $db->query($sql);
            // print_r($result);
            if ($result->num_rows > 0){
                while ($row = $result->fetch_assoc()){
                    // print_r($row);
                    $str .= " <input type='checkbox' class='delete-checkbox' name='checkbox[]' value='" . $row['SKU'] . "'><div class='product'>
                     " 
                    . $row["name"] . "<br> " 
                    . $row["price"] . "<br> " 
                    . $row["dimensions"].
                    "</div>";
                }
            }
            return $str;
        }

        public function InsertItems(): bool{
            $flag = false;
            $db = new Database('id18124192_productlist');
            $db->db_connect();
            if ($_POST['w'] == "" ||  $_POST['l'] == "" ||  $_POST['h'] == ""){
                return $flag;
            }
            products::Set_SKU($_POST['sku']);
            products::Set_Name($_POST['name']);
            products::Set_price($_POST['price']);
            
            $this->Set_dimensions($_POST['w'], $_POST['l'], $_POST['h']);

            $query = "insert into furniture (SKU, name, price, dimensions) VALUES ('".products::Get_SKU()."', '".products::Get_Name()."', '".products::Get_price()."', '".$this->Get_dimenions()."')";
            
            if ($db->query($query)){
                $flag = true;
            }
            return $flag;
        }




        public function __toString(){
            return "ID: " . $this->Get_SKU() 
            . "<br> Name: " . $this->Get_name() 
            . "<br> price: " . $this->Get_price() 
            . "<br> size: " . $this->Get_dimenions() 
            . "<br>";
        }

        // public function Set_SKU($SKU){
        //     $this->$SKU = $SKU;
        // }

        // public function Set_Name($name){
        //     $this->$name = $name;
        // }
        
        // public function Set_price($price){
        //     $this->$price = $price;
        // }

        public function Set_dimensions($w, $l, $h){
            $this->w  = $w;
            $this->l  = $l;
            $this->h  = $h;
        }

        public function Get_dimenions(){
            return $this->w . "x" . $this->h . "x" . $this->l;
        }
    }



?>