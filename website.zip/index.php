<?php 
    require_once("Server.php");
    require_once("product.php");
    // $db = new Database("productlist");
    // $db->db_connect();

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="styles/stylesheet.css">
    <title>Product list</title>
</head>
<body>

    <div class="photo-container">

    </div>
    <span class="header-1">
        <div class="head-1">
            <form action="Delete.php" method="post" name="delete_form">
            <h1>
            Product list
            </h1>   
            <input type="button" value = "ADD" onclick="window.location='https://elemental-apparatus.000webhostapp.com/add.php'"/>
            <!--<form action="">-->
            <!--    <input type="button" value = "ADD" name="add-btn" >-->
            <!--</form>-->
            
                
            <input type="submit" name="delete" value="MASS DELETE" id="delete-product-btn">
            <!-- <hr> -->
        </div>
    </span>
    <div class="wrapper-1">
        <div id="product-list">
            <?php
                $dvd = new dvd();
                $book = new book();
                $furniture = new furniture();
                echo ($dvd->GetData());
                echo ($book->GetData());
                echo ($furniture->GetData());
                
            ?>
        </div>
    </div>
            </form>
            
</body>
</html>


